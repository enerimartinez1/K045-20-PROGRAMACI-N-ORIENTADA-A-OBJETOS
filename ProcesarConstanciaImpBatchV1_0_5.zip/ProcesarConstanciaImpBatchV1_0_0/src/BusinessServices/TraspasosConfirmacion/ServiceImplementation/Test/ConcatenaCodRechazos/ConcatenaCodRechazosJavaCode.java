package BusinessServices.TraspasosConfirmacion.ServiceImplementation.Test.ConcatenaCodRechazos;
public class ConcatenaCodRechazosJavaCode{
/****** START SET/GET METHOD, DO NOT MODIFY *****/
	protected String stringMotivos = "";
	protected String[] idMotivo = null;
	public String getstringMotivos() {
		return stringMotivos;
	}
	public void setstringMotivos(String val) {
		stringMotivos = val;
	}
	public String[] getidMotivo() {
		return idMotivo;
	}
	public void setidMotivo(String[] val) {
		idMotivo = val;
	}
/****** END SET/GET METHOD, DO NOT MODIFY *****/
	public ConcatenaCodRechazosJavaCode() {
	}
	public void invoke() throws Exception {
/* Available Variables: DO NOT MODIFY
	In  : String stringMotivos
	Out : String[] idMotivo
* Available Variables: DO NOT MODIFY *****/
    
    int len = getstringMotivos().length();

    // Number of parts
    int nparts = (len + 3 - 1) / 3;
    String parts[] = new String[nparts];

    // Break into parts
    int offset= 0;
    int i = 0;
    while (i < nparts)
    {
        parts[i] = getstringMotivos().substring(offset, Math.min(offset + 3, len));
        offset += 3;
        i++;
    }

    setidMotivo(parts);
}
}

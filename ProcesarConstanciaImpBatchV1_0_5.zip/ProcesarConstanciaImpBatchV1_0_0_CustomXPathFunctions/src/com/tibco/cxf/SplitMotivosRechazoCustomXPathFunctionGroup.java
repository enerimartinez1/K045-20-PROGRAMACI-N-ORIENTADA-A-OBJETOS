package com.tibco.cxf;
import com.tibco.SplitMotivosRechazo;
import com.tibco.xml.cxf.common.annotations.XPathFunction;
import com.tibco.xml.cxf.common.annotations.XPathFunctionGroup;
import com.tibco.xml.cxf.common.annotations.XPathFunctionParameter;
import java.lang.String;
import java.lang.String;
@XPathFunctionGroup(category="com.tibco",prefix="SplitString",namespace="java://com.tibco.SplitMotivosRechazo",helpText="com.tibco.SplitMotivosRechazo") public class SplitMotivosRechazoCustomXPathFunctionGroup {
  @XPathFunction(parameters={@XPathFunctionParameter(name="string1"),@XPathFunctionParameter(name="int2"),@XPathFunctionParameter(name="string3")},helpText="") public java.lang.String idMotivos(  java.lang.String string1,  int int2,  java.lang.String string3){
    return SplitMotivosRechazo.idMotivos(string1,int2,string3);
  }
}

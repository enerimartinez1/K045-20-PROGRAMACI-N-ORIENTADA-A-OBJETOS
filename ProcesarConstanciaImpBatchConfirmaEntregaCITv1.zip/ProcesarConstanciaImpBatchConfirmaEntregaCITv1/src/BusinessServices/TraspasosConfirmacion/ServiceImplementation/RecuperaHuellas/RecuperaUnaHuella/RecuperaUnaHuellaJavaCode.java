package BusinessServices.TraspasosConfirmacion.ServiceImplementation.RecuperaHuellas.RecuperaUnaHuella;
import org.json.JSONObject;
import org.json.XML;

public class RecuperaUnaHuellaJavaCode{
/****** START SET/GET METHOD, DO NOT MODIFY *****/
	protected String JsonString = "";
	protected String XmlString = "";
	public String getJsonString() {
		return JsonString;
	}
	public void setJsonString(String val) {
		JsonString = val;
	}
	public String getXmlString() {
		return XmlString;
	}
	public void setXmlString(String val) {
		XmlString = val;
	}
/****** END SET/GET METHOD, DO NOT MODIFY *****/
	public RecuperaUnaHuellaJavaCode() {
	}
	public void invoke() throws Exception {
/* Available Variables: DO NOT MODIFY
	In  : String JsonString
	Out : String XmlString
* Available Variables: DO NOT MODIFY *****/
	try
    	{
    		String jsonStr = getJsonString();
    		JSONObject jsonObj = new JSONObject(jsonStr);
    		setXmlString(XML.toString(jsonObj));
   	 }
   	 catch (Exception e)
   	 {
   	     e.printStackTrace();
   	 }
}
}
